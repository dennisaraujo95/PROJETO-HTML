from flask import Flask, render_template, jsonify, request
import requests

app = Flask(__name__)


produtos = {
    "lanches": [
        {"nome": "X-Burguer", "preco": 15.90},
        {"nome": "X-Salada", "preco": 18.50},
        {"nome": "X-Bacon", "preco": 20.00},
        {"nome": "Beirute", "preco": 22.50}
    ],
    "bebidas": [
        {"nome": "Refrigerante 2L", "preco": 12.00},
        {"nome": "Refrigerante Lata", "preco": 6.00},
        {"nome": "Suco Natural", "preco": 8.00}
    ],
    "sobremesas": [
        {"nome": "Pudim", "preco": 10.00},
        {"nome": "Mousse de Chocolate", "preco": 12.00},
        {"nome": "Brownie", "preco": 15.00}
    ],
    "acompanhamentos": [
        {"nome": "Batata Frita", "preco": 14.00},
        {"nome": "Onion Rings", "preco": 16.00},
        {"nome": "Dadinho de Tapioca", "preco": 18.00},
        {"nome": "Batata Frita com Cheddar e Bacon", "preco": 20.00}
    ]
}

@app.route('/')
def home():
    
    return render_template('index.html')

@app.route('/api/cardapio')
def get_cardapio():
    
    return jsonify(produtos)

@app.route('/api/calcular_frete', methods=['POST'])
def calcular_frete_api():
    
    data = request.get_json()
    cep = data.get('cep')

    if not cep:
        return jsonify({"erro": "CEP não fornecido."}), 400

    try:
        response = requests.get(f"https://viacep.com.br/ws/{cep}/json/")
        data = response.json()
        print (data) # Isso é útil para depuração, você pode remover em produção
        if data.get('erro'):
            return jsonify({"erro": "CEP inválido."}), 400
        
        # Simulação de cálculo de frete com base na localidade
        # Você pode ajustar essa lógica conforme a necessidade
        distancia = 5 if data.get('localidade') == "Santo André" else 10 # Exemplo: simula uma distância maior para outras cidades
        frete = distancia * 2 # Exemplo: R$ 2,00 por unidade de distância

        # Retorna todos os dados relevantes do endereço ViaCEP e o frete
        return jsonify({
            "frete": frete,
            "cep": data.get('cep'),
            "logradouro": data.get('logradouro'),
            "bairro": data.get('bairro'),
            "localidade": data.get('localidade'),
            "uf": data.get('uf')
        })

    except requests.exceptions.RequestException:
        return jsonify({"erro": "Erro ao conectar com a API de CEP."}), 500
    except Exception as e:
        return jsonify({"erro": f"Erro inesperado: {e}"}), 500

@app.route('/checkout')
def checkout():
    """
    Renderiza a página de finalização do pedido.
    """
    return render_template('checkout.html')


if __name__ == '__main__':
    
    app.run(debug=True)
