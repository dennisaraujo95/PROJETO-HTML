const carrinho = [];
const totalElement = document.getElementById("total");
const searchInput = document.getElementById("search");
const freteInfo = document.getElementById("frete-info");
const btnFinalizarPedido = document.getElementById("btn-finalizar-pedido");

// Variável global para armazenar os produtos carregados do backend
let produtosCarregados = {};
// Variável global para armazenar os detalhes do endereço do frete
let enderecoFrete = null;

async function buscarProdutosDoBackend() {
    try {
        // Chama a API /api/cardapio no seu servidor Flask
        const response = await fetch('/api/cardapio');
        produtosCarregados = await response.json(); // Armazena os dados do cardápio
        exibirProdutos(); // Exibe os produtos na interface após carregá-los
    } catch (error) {
        console.error("Erro ao carregar produtos do backend:", error);
        // Opcional: exiba uma mensagem de erro na interface do usuário
        alert("Não foi possível carregar o cardápio. Tente novamente mais tarde.");
    }
}

/**
 * Exibe os produtos no cardápio, filtrando-os se um termo de busca for fornecido.
 * @param {string} searchTerm - O termo de busca para filtrar os produtos. Padrão é uma string vazia (nenhum filtro).
 */
function exibirProdutos(searchTerm = '') {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();

    // Limpa o conteúdo de todas as categorias antes de exibir os produtos filtrados
    document.getElementById("lanches").innerHTML = "";
    document.getElementById("bebidas").innerHTML = "";
    document.getElementById("sobremesas").innerHTML = "";
    document.getElementById("acompanhamentos").innerHTML = "";

    // Itera sobre cada categoria de produto em 'produtosCarregados'
    for (const [categoryName, productList] of Object.entries(produtosCarregados)) {
        const categoryContainer = document.getElementById(categoryName);
        
        // Filtra os produtos da categoria atual com base no termo de busca
        const filteredProducts = productList.filter(product =>
            product.nome.toLowerCase().includes(lowerCaseSearchTerm)
        );

        // Cria e adiciona os cards para os produtos filtrados
        filteredProducts.forEach((product, index) => {
            const productCard = document.createElement("div");
            productCard.classList.add("card");
            // Nota: o 'index' aqui se refere ao índice DENTRO da lista filtrada,
            // não no objeto 'produtosCarregados' original. Isso pode causar problemas
            // se você adicionar um item que foi filtrado e o índice não corresponder.
            // Uma abordagem mais robusta seria passar o nome do produto ou um ID único.
            // Para simplicidade, mantive o index como estava, mas é um ponto a observar.
            productCard.innerHTML = `
                <p>${product.nome}</p>
                <p>R$ ${product.preco.toFixed(2)}</p>
                <button onclick="adicionarAoCarrinho('${categoryName}', ${index})">Adicionar</button>
            `;
            categoryContainer.appendChild(productCard);
        });
    }
}

// Event listener para a barra de pesquisa
searchInput.addEventListener('input', () => {
    const currentSearchTerm = searchInput.value;
    exibirProdutos(currentSearchTerm);
});

// Adicionar produto ao carrinho
function adicionarAoCarrinho(categoria, index) {
    // Usamos 'produtosCarregados' que contém os dados do cardápio do backend
    // ATENÇÃO: O 'index' passado aqui é o índice na lista FILTRADA.
    // Para um sistema mais robusto, o ideal seria passar o nome do produto ou um ID único
    // e procurar esse item em 'produtosCarregados'.
    const itemAdicionado = produtosCarregados[categoria][index];
    if (itemAdicionado) {
        carrinho.push(itemAdicionado);
        atualizarCarrinho();
    } else {
        console.error("Item não encontrado para adicionar ao carrinho.", categoria, index);
    }
}

// Atualizar carrinho e total
function atualizarCarrinho() {
    const listaCarrinho = document.getElementById("lista-carrinho");
    listaCarrinho.innerHTML = "";
    let total = 0;

    carrinho.forEach((item, index) => {
        const produtoCarrinho = document.createElement("li");
        produtoCarrinho.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
        const botaoRemover = document.createElement("button");
        botaoRemover.textContent = "Remover";
        botaoRemover.onclick = () => removerDoCarrinho(index);
        produtoCarrinho.appendChild(botaoRemover);
        listaCarrinho.appendChild(produtoCarrinho);
        total += item.preco;
    });

    totalElement.textContent = `R$ ${total.toFixed(2)}`;

    // Exibe ou oculta o botão "Finalizar Pedido"
    if (carrinho.length > 0 && freteInfo.textContent.includes('Frete')) {
        btnFinalizarPedido.style.display = 'block';
    } else {
        btnFinalizarPedido.style.display = 'none';
    }
}

// Remover produto do carrinho
function removerDoCarrinho(index) {
    carrinho.splice(index, 1);
    atualizarCarrinho();
}

/**
 * Calcula o frete chamando a API do Flask e armazena os dados do endereço.
 */
async function calcularFrete() {
    const cep = document.getElementById("cep").value;

    if (!cep) {
        freteInfo.textContent = "Por favor, digite um CEP válido.";
        btnFinalizarPedido.style.display = 'none'; // Oculta o botão se o CEP for inválido
        return;
    }

    try {
        // Envia o CEP para a API de frete do Flask via requisição POST
        const response = await fetch('/api/calcular_frete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cep: cep })
        });
        const data = await response.json();

        if (data.erro) {
            freteInfo.textContent = data.erro;
            btnFinalizarPedido.style.display = 'none'; // Oculta o botão se houver erro no frete
            return;
        }
        
        const frete = data.frete;
        const totalCompra = carrinho.reduce((acc, item) => acc + item.preco, 0);
        const totalComFrete = totalCompra + frete;

        freteInfo.textContent = `Frete: R$ ${frete.toFixed(2)} | Total com Frete: R$ ${totalComFrete.toFixed(2)}`;
        
        // Armazena os dados completos do endereço recebidos da API (ViaCEP)
        enderecoFrete = {
            logradouro: data.logradouro,
            bairro: data.bairro,
            localidade: data.localidade,
            uf: data.uf,
            cep: data.cep,
            frete: frete,
            totalComFrete: totalComFrete
        };

        // Exibe o botão "Finalizar Pedido" após o cálculo bem-sucedido do frete
        if (carrinho.length > 0) {
            btnFinalizarPedido.style.display = 'block';
        }

    } catch (error) {
        console.error("Erro ao calcular o frete via API Flask:", error);
        freteInfo.textContent = "Erro ao calcular o frete.";
        btnFinalizarPedido.style.display = 'none'; // Oculta o botão em caso de erro
    }
}

/**
 * Redireciona para a página de finalização do pedido, passando os dados necessários.
 */
function finalizarPedido() {
    if (carrinho.length === 0) {
        alert("Seu carrinho está vazio. Adicione itens antes de finalizar o pedido.");
        return;
    }
    if (!enderecoFrete) {
        alert("Por favor, calcule o frete antes de finalizar o pedido.");
        return;
    }

    // Prepara os dados para serem passados para a página de finalização
    const dadosPedido = {
        carrinho: carrinho,
        totalGeral: enderecoFrete.totalComFrete,
        frete: enderecoFrete.frete,
        endereco: {
            logradouro: enderecoFrete.logradouro,
            bairro: enderecoFrete.bairro,
            localidade: enderecoFrete.localidade,
            uf: enderecoFrete.uf,
            cep: enderecoFrete.cep
        }
    };

    // Armazena os dados no sessionStorage para acesso na próxima página
    sessionStorage.setItem('dadosPedido', JSON.stringify(dadosPedido));

    // Redireciona para a página de finalização
    window.location.href = '/checkout';
}


// Chamada inicial ao carregar a página
// 'DOMContentLoaded' garante que o HTML está pronto antes de tentar manipulá-lo
document.addEventListener("DOMContentLoaded", () => {
    buscarProdutosDoBackend(); // Inicia o carregamento dos produtos
    atualizarCarrinho(); // Garante que o carrinho é exibido (mesmo que vazio)
});
